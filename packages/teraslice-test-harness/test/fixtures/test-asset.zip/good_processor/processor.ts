import { DataEntity, AnyObject, MapProcessor } from '@terascope/job-components';

export default class GoodProcessor extends MapProcessor<AnyObject> {
    map(doc: DataEntity): DataEntity {
        doc.setMetadata('external', true);
        return doc;
    }
}
