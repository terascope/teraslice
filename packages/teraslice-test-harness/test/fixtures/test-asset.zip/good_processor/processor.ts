import { MapProcessor } from '@terascope/job-components';
import { DataEntity } from '@terascope/core-utils';

export default class GoodProcessor extends MapProcessor<Record<string, any>> {
    map(doc: DataEntity): DataEntity {
        doc.setMetadata('external', true);
        return doc;
    }
}
